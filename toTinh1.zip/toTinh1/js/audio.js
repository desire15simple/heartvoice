var GFG = document.getElementById("idAudio");
function play_Audio() {
    GFG.play();
}
function pause_Audio() {
    GFG.pause();
}
